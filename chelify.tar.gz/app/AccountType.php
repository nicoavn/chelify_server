<?php
/**
 * Created by PhpStorm.
 * User: alvin
 * Date: 14/11/2017
 * Time: 8:52 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{

}